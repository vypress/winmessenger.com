*******************************************************************************
      SEND.EXE: Command-line utility for automating Vypress Chat 1.x
*******************************************************************************

This is little console command-line utility designed for automate Vypress Chat
messages and events. It is useful for BAT and CMD files and sending notification
from an external application to the Vypress Chat.

Although, it is extremely small utility (50KB), it contains all the
functionality you can find in the Vypress Chat. This utility is written as part
of Vypress Chat 2.0 project, so any feedback on it is greatly appreciated.
Please write to support@vypress.com.

*******************************************************************************

Usage: send [switch] [options] (first_parameter) [second_parameter]
Switches:
	/?	displays usage text
	/v	version info
	/m	mass message: send /m (nickname) (message)
	/p	private line: send /p (nickname) (line)
	/c	channel line: send /c (channel) (line)
	/r	sound request: send /r (channel) (wavefilename)
	/e	remote execution: send /e (nickname) (execline)
	/a	action /me: send /a (channel) (line)
	/b	beep: send /b (nickname)
	/t	new topic: send /t (channel) (newtopic)

First and/or second parameter can also be defined in following format:
({text} | {text1;text2;...;textN} | {/f text_filename})

Options:
	/pass (passwd)	execution password
	/P[1-65535]	default UDP/IPX port
	/T[0-2]		type of network protocol
			0 - IP Broadcast
			1 - IP Multicast
			2 - IPX Broadcast
	/L[0-15]	TTL for IP Multicast sending
	/M [IP]		IP Multicast group
	/N [name]	your nickname

*******************************************************************************
  Copyright(C)2000 VyPRESS Research, LLC. 
  http://www.vypress.com
  