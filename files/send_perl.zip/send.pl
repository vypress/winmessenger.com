#!/usr/bin/perl

# format for sending data to VM is:
# UserName/$0
# MessageText/$1
# SystemName/$2
# Subject/$3
# Priority/$4

($MessageText,$station,$UserName,$SystemName,$Subject) = @ARGV;

if ($MessageText eq '') {
  print "\n";
  print "For sending MessageTexts to Vypress Messenger\n";
  print "\n";
  print "popupwrite 'MessageText' [tostation] [fromuser] [fromstation]\n";
  print "\n";
  print " MessageText        is a string\n";
  print " tostation      is machine to write to      (default: localhost)\n";
  print " fromuser       is your name                (default: login)\n";
  print " fromstation    is your computer            (default: FooBar)\n";
  print " Subject        is the window title         (default: A MessageText!)\n";
  print "\n";
  exit;
}

# DEFAULTS
$station = 'localhost' unless $station;		# set to site running VM 
$UserName = `whoami` unless $UserName;		# this tells who is sending 
$Subject = 'A MessageText!' unless $Subject;	# title of popup
$SystemName = 'FooBar' unless $SystemName;	# from some computer
$Priority = '0';				# prio=1 says alert or somesuch 

$port = 7777;					# default VM port

#
# Telnet code from O'Reilly
#

$AF_INET = 2;
$SOCK_STREAM = 1;

$sockaddr = 'S n a4 x8';

chop($hostname = `hostname`);

($name,$aliases,$proto) = getprotobyname('tcp');
($name,$aliases,$port) = getservbyname($port,'tcp')
    unless $port =~ /^\d+$/;;
($name,$aliases,$type,$len,$thisaddr) =
	gethostbyname($hostname);
($name,$aliases,$type,$len,$thataddr) = gethostbyname($station);

$this = pack($sockaddr, $AF_INET, 0, $thisaddr);
$that = pack($sockaddr, $AF_INET, $port, $thataddr);

# Make the socket filehandle.

if (! (socket(S, $AF_INET, $SOCK_STREAM, $proto))) { 
    print "socket failed!\n";
    die $!;
}

# Give the socket an address.

if (! (bind(S, $this))) {
    print "bind failed!\n";
    die $!;
}

# Call up the server.

if (! (connect(S,$that))) {
    print "connect failed!\n";
    die $!;
}

# Set socket to be command buffered.

select(S); $| = 1; select(STDOUT);

# Send that MessageText!

print S "$UserName/\$0$MessageText/\$1$SystemName/\$2$Subject/\$3$Priority/\$4\n"; 

# da end
