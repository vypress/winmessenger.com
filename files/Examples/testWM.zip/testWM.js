function UsersListEventsListener()
{
	this.OnUsersListUpdate = UsersListEventsListener_OnUsersListUpdate;
}

function MesssagesListener()
{
	this.OnReceiveMessage = MesssagesListener_OnReceiveMessage;
	this.OnServiceError = MesssagesListener_OnServiceError;
}

function UsersListEventsListener_OnUsersListUpdate(unitFlag)
{
	WScript.Echo(unitFlag + "\r\n" + "OnUsersListUpdate");
}

function MesssagesListener_OnReceiveMessage(intMsgType, strFrom, strTo, strText)
{
	WScript.Echo(intMsgType + "\r\n" + strFrom + "\r\n" + strTo +"\r\n" + strText);
}

function MesssagesListener_OnServiceError(intErrType, lngErr, lngErrData, strName, strError)
{
     WScript.Echo(intErrType + "\r\n" + lngErr + "\r\n" + lngErrData + "\r\n" + strName + "\r\n" + strError);
}

WScript.Echo("Started...");
//Create WmServiceUsersList object with the connection point
var ule_prov = WScript.CreateObject("VyPRESS.WinMessenger.WmServiceUsersList", "UsersListEventsListener_");
var wmservice = WScript.CreateObject("VyPRESS.WinMessenger.WmService");

var astrNames = new Array("USER1", "USER2", "*");

//var ule_listener = UsersListEventsListener;
//ule_prov.AddUsersListEventsListener(ule_listener);

var msg_listener = new MesssagesListener;

var retVal = wmservice.AddNames(astrNames, msg_listener);

WScript.Echo("Press OK to stop service...");

wmservice.RemoveListener(msg_listener);
//ule_prov.RemoveUsersListEventsListener(ule_listener);
