﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Xml.Serialization;

using System.IO;
using System.Text;

namespace LogMessagesWebService
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Service1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string LogMessage(LoggedMessage message)
        {
            string Result = "Error";
            if (message == null) return Result;

            StreamWriter writer = null;
            try
            {
                if (message.sent)
                {
                    writer = new StreamWriter("C:\\Temp\\SentMessages.txt", true);
                }
                else
                {
                    writer = new StreamWriter("C:\\Temp\\ReceivedMessages.txt", true);
                }

                writer.WriteLine(message.datetime);
                writer.WriteLine("Message from {0} to {1}.", message.from.name, message.to.name);
                writer.WriteLine(message.text);
                writer.WriteLine("\r\n----------------------------------------------------------------------\r\n");

                Result = "Successful";
            }
            catch (Exception e)
            {
                Result = e.Message;
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }

            return Result;
        }
    }

    [XmlRoot(Namespace = "http://www.winmessenger.com/message28")]
    [XmlType(Namespace = "http://www.winmessenger.com/message28")]
    public class LoggedMessage
    {
        /*
       <message type="Mailslot" datetime="2007-11-29T18:38:19.789-03:00" unread="true" sent="true">
       <from>
       <name>Aleksey Vyatkin</name>
       <netbios_name>ALEKSEY VYATKIN</netbios_name>
       </from>
       <to>
       <name>Vista</name>
       <netbios_name>VISTA</netbios_name>
       </to>
       <text>Привет! -----Original Message----- >yetyery >:@</text> 
       <send_result>
       <result error="61726176271">
       <name>Vista</name>
       <netbios_name>VISTA</netbios_name>
       <description>The name cannot be found</description>
       </result>
       </send_result>
       <message>
       */
        [XmlAttribute]
        public string type;

        [XmlAttribute]
        public DateTime datetime;

        [XmlAttribute]
        public bool unread = true;

        [XmlAttribute]
        public bool sent;

        public NbAddress from;
        public NbAddress to;
        public string text;

        public result[] send_result;
    }

    public class NbAddress
    {
        public string name;
        public string netbios_name;
    }

    public class result
    {
        [XmlAttribute]
        public uint error;

        public string name;
        public string netbios_name;
        public string description;
    }
}
