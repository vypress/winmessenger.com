var boolExit = false;

function SendEventsListener()
{
	this.OnSendStatusChanged = SendEventsListener_OnSendStatusChanged;
}

function SendEventsListener_OnSendStatusChanged(lCookie, varStatuses, bFinal)
{
	WScript.Echo("OnSendStatusChanged");
	boolExit = true;
}

function MesssagesListener()
{
	this.OnReceiveMessage = MesssagesListener_OnReceiveMessage;
	this.OnServiceError = MesssagesListener_OnServiceError;
}

function MesssagesListener_OnReceiveMessage(intMsgType, strFrom, strTo, strText)
{
	WScript.Echo(intMsgType + "\r\n" + strFrom + "\r\n" + strTo +"\r\n" + strText);
}

function MesssagesListener_OnServiceError(intErrType, lngErr, lngErrData, strName, strError)
{
     WScript.Echo(intErrType + "\r\n" + lngErr + "\r\n" + lngErrData + "\r\n" + strName + "\r\n" + strError);
}

WScript.Echo("Started...");

var wmservice = WScript.CreateObject("VyPRESS.WinMessenger.WmService");

var astrNames = new Array("USER_SEND");

var msg_listener = new MesssagesListener;

var retVal = wmservice.AddNames(astrNames, msg_listener);

var listener = new SendEventsListener;

var toNames = new Array("USER2");

var lCookie = wmservice.SendTextMessage(1, toNames, "USER_SEND", "sent \r\n text 2", listener);
WScript.Echo("Sent message ID is " + lCookie);

while(!boolExit)
{
    WScript.Sleep(100);
}

wmservice.RemoveListener(msg_listener);