﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

using System.Runtime.InteropServices;
using System.Collections.Generic;

using WinMessengerService;

namespace WmWebApplication
{
	public class MessagesListener : _IMessagesListener
	{
		//One queue for each client, the key is Request.UserHostName
		private Dictionary<string, Queue> _queuesOfMessages;

		public MessagesListener()
		{
			_queuesOfMessages = new Dictionary<string, Queue>();
		}

		public void AddName(string strName)
		{
			_queuesOfMessages[strName] = new Queue();
		}

		public void RemoveName(string strName)
		{
			_queuesOfMessages.Remove(strName);
		}

		public string GetMessage(string strName)
		{
			if (_queuesOfMessages[strName] != null)
			{
				string strMessage = "";

				if (_queuesOfMessages[strName].Count>0)
					strMessage = _queuesOfMessages[strName].Dequeue() as string;

				return strMessage;
			}

			return "";
		}

		#region _IMessagesListener Members

		public void OnReceiveMessage(MSG_TYPE nType, String strFrom, String strTo, String strMsg)
		{
			if (nType == MSG_TYPE.MAILSLOT || (strTo == WmWebApplication.Global._strFrom))
			{
				//Add message to all connected clients
				foreach (KeyValuePair<string, Queue> q in _queuesOfMessages)
				{
					q.Value.Enqueue(
						String.Format("Message from {0} to {1}.\r\n{2}", strFrom, strTo, strMsg));
				}
				return;
			}

			if (_queuesOfMessages[strTo] != null)
				_queuesOfMessages[strTo].Enqueue(String.Format("Message from {0} to {1}.\r\n{2}", strFrom, strTo, strMsg));
		}

		public void OnServiceError(int nErrType, int lErr, int lErrData, String strName, String strError)
		{
			if (_queuesOfMessages[strName] != null)
				_queuesOfMessages[strName].Enqueue(String.Format("Error information:\r\ndata1: {0:X8}\r\ndata2: {1:X8}\r\ndata3: {2:X8}\r\nname: {3}\r\ndescription: {4}", nErrType, lErr, lErrData, strName, strError));
		}

		#endregion
	}

	public class Global : System.Web.HttpApplication
	{
		public const String _strFrom = "WEB_SERVER";

		static public CoWinMessengerClass _CoWmService = null;
		static public CoWinMessengerUsersListProviderClass _CoUsersListProvider = null;
		static public MessagesListener _MsgListener = null;

		protected void Application_Start(object sender, EventArgs e)
		{
			_MsgListener = new MessagesListener();

			String[] arrayFrom = { _strFrom, @"*" };
			_CoWmService = new CoWinMessengerClass();
			_CoWmService.AddNames(arrayFrom, _MsgListener);
			_CoUsersListProvider = new CoWinMessengerUsersListProviderClass();
		}

		protected void Session_Start(object sender, EventArgs e)
		{
			Session.Timeout = 1;//1 min time out
			Session["nbname"] = Request.UserHostName;

			if (_CoWmService != null && _MsgListener!=null)
			{
				_MsgListener.AddName(Request.UserHostName);
				String[] arrayFrom = { Request.UserHostName };
				_CoWmService.AddNames(arrayFrom, _MsgListener);
			}
		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{
			string strName = Session["nbname"] as string;
			if (strName == null) return;

			_MsgListener.RemoveName(strName);

			if (_CoWmService != null)
			{
				String[] arrayFrom = { strName };
				_CoWmService.RemoveNames(arrayFrom, _MsgListener);
			}

		}

		protected void Application_End(object sender, EventArgs e)
		{
			if (_CoWmService != null)
				_CoWmService.RemoveListener(_MsgListener);

			_MsgListener = null;
			_CoWmService = null;
			_CoUsersListProvider = null;
		}
	}
}