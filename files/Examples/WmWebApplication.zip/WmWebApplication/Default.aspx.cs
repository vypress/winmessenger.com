﻿using System;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using WinMessengerService;

namespace WmWebApplication
{
	public partial class _Default : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
				LoadUsersList();
		}

		public void LoadUsersList()
		{
			//WmWebApplication.Global WmApp = Context.ApplicationInstance as WmWebApplication.Global;

			selectAddress.Items.Clear();
			Object[,] obj_ul = WmWebApplication.Global._CoUsersListProvider.GetUsersList() as Object[,];
			if (obj_ul == null) return;

			int loBound0 = obj_ul.GetLowerBound(0);
			int upBound0 = obj_ul.GetUpperBound(0);

			string strPadding = Server.HtmlDecode(@"&nbsp;&nbsp;");

			for (int i = loBound0; i <= upBound0; i++)
			{
				ListItem lItem = new ListItem();
				lItem.Text = obj_ul[i, 0] as String;
				lItem.Value = lItem.Text;
				selectAddress.Items.Add(lItem);

				Object[,] obj_next_ul = obj_ul[i, 3] as Object[,];

				if (obj_next_ul == null) continue;

				int loBound00 = obj_next_ul.GetLowerBound(0);
				int upBound00 = obj_next_ul.GetUpperBound(0);
				for (int j = loBound00; j <= upBound00; j++)
				{
					ListItem lInnerItem = new ListItem();
					lInnerItem.Text = strPadding + obj_next_ul[j, 0];
					lInnerItem.Value = @"  " + obj_next_ul[j, 0];
					selectAddress.Items.Add(lInnerItem);
				}
			}
		}

		protected void buttonSend_Click(object sender, EventArgs e)
		{
			SendEventsListener se_listener = new SendEventsListener();
			String[] arrayTo = { selectAddress.Text.Trim() };

			MSG_TYPE msgType = radioUser.Checked ? MSG_TYPE.SMB : MSG_TYPE.MAILSLOT;
			se_listener.Cookie = WmWebApplication.Global._CoWmService.SendTextMessage(msgType, arrayTo, Request.UserHostName, textMessage.Text, se_listener);

			if (se_listener.Cookie != -1)
			{
				//Wait while message is sending...
				while (se_listener._state != 0)
					System.Threading.Thread.Sleep(100);
			}

			if (se_listener._statuses == null)
			{
				Page.ClientScript.RegisterStartupScript(this.GetType(), "MessageBoxScript", String.Format("alert(\'Unable to send the message with ID {0}.\');", se_listener.Cookie), true);
				return;
			}

			int loBound0 = se_listener._statuses.GetLowerBound(0);
			int upBound0 = se_listener._statuses.GetUpperBound(0);

			for (int i = loBound0; i <= upBound0; i++)
			{
				UInt32 nStatus = (UInt32)se_listener._statuses[i, 1];
				if (nStatus == 0)
					Page.ClientScript.RegisterStartupScript(this.GetType(), "MessageBoxScript", String.Format("alert(\'The message to {0} was sent successfully.\');", se_listener._statuses[i, 0]), true);
				else
					Page.ClientScript.RegisterStartupScript(this.GetType(), "MessageBoxScript", String.Format("alert(\'Unable to send the message to {0}.\');", se_listener._statuses[i, 0]), true);
			}
		}

		protected void buttonUpdate_Click(object sender, EventArgs e)
		{
			LoadUsersList();
		}
	}

	public class SendEventsListener : _ISendEventsListener
	{
		public int _state;
		public Object[,] _statuses;
		int _cookie;

		public SendEventsListener()
		{
			_state = -1;
			_cookie = -1;
		}

		public int Cookie
		{
			set
			{
				_cookie = value;
			}

			get
			{
				return _cookie;
			}

		}

		#region _ISendEventsListener Members

		public void OnSendStatusChanged(int lCookie, object varStatuses, bool bFinal)
		{
			if (!bFinal) return;

			if (_cookie == lCookie)
			{
				_state = 0;
				_statuses = varStatuses as Object[,];
			}
			//throw new NotImplementedException();
		}

		#endregion
	}
}
