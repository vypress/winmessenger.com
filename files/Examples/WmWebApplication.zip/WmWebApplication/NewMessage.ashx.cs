﻿using System;
using System.Collections.Generic;
using System.Web;

namespace WmWebApplication
{
	/// <summary>
	/// Summary description for $codebehindclassname$
	/// </summary>
	//[WebService(Namespace = "http://tempuri.org/")]
	//[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
	public class NewMessage : IHttpHandler
	{
		public void ProcessRequest(HttpContext context)
		{
			//Disable caching
			context.Response.Cache.SetCacheability(HttpCacheability.NoCache);
			context.Response.ContentType = "text/plain";

			if (WmWebApplication.Global._MsgListener != null)
				context.Response.Write(WmWebApplication.Global._MsgListener.GetMessage(context.Request.UserHostName));
		}

		public bool IsReusable
		{
			get
			{
				return false;
			}
		}
	}
}
