
// TestImgHtmlDoc.cpp : implementation of the CTestImgHtmlDoc class
//

#include "stdafx.h"
#include "TestImgHtml.h"

#include "TestImgHtmlDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTestImgHtmlDoc

IMPLEMENT_DYNCREATE(CTestImgHtmlDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestImgHtmlDoc, CDocument)
END_MESSAGE_MAP()


// CTestImgHtmlDoc construction/destruction

CTestImgHtmlDoc::CTestImgHtmlDoc()
{
	// TODO: add one-time construction code here

}

CTestImgHtmlDoc::~CTestImgHtmlDoc()
{
}

BOOL CTestImgHtmlDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CTestImgHtmlDoc serialization

void CTestImgHtmlDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CTestImgHtmlDoc diagnostics

#ifdef _DEBUG
void CTestImgHtmlDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestImgHtmlDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CTestImgHtmlDoc commands

BOOL CTestImgHtmlDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// TODO:  Add your specialized creation code here
	m_strPath = lpszPathName;

	return TRUE;
}
