
// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "TestImgHtml.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWndEx)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_WM_SIZE()
	ON_WM_SIZING()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_ENTERSIZEMOVE()
	ON_WM_EXITSIZEMOVE()

	ON_NOTIFY(TVN_ITEMEXPANDING, 1, OnTreeItemExpanding )
	ON_NOTIFY(TVN_SELCHANGED, 1, OnTreeItemChanged )
	ON_NOTIFY(LVN_ITEMCHANGED, 2, OnListItemChanged )

END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	m_nIdleFlags &= ~idleLayout;

	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create a tree of directories
	if (!m_wndDirsCtrl.Create(WS_CHILD | WS_VISIBLE | WS_BORDER|TVS_SINGLEEXPAND|TVS_TRACKSELECT|TVS_HASLINES|TVS_LINESATROOT|TVS_HASBUTTONS, CRect(0, 0, 0, 0), this, 1))
	{
		TRACE0("Failed to create tree window\n");
		return -1;
	}

	// create a list of files
	if (!m_wndFilesCtrl.Create(WS_CHILD | WS_VISIBLE | WS_BORDER|LVS_SORTASCENDING|LVS_LIST|LVS_SINGLESEL|LVS_SHAREIMAGELISTS, CRect(0, 0, 0, 0), this, 2))
	{
		TRACE0("Failed to create tree window\n");
		return -1;
	}

	m_wndFilesCtrl.SetExtendedStyle(LVS_EX_ONECLICKACTIVATE |LVS_EX_UNDERLINEHOT);

	//Fill lists
	FillDisks();

	BOOL bNameValid;

	// set the visual manager used to draw all user interface elements
	CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("Failed to create menubar\n");
		return -1;      // fail to create
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// prevent the menu bar from taking the focus on activation
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: Delete these five lines if you don't want the toolbar and menubar to be dockable
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// enable Visual Studio 2005 style docking window behavior
	CDockingManager::SetDockingMode(DT_SMART);
	// enable Visual Studio 2005 style docking window auto-hide behavior
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// Enable toolbar and docking window menu replacement
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// enable quick (Alt+drag) toolbar customization
	CMFCToolBar::EnableQuickCustomization();

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPCHILDREN;

	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame message handlers

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* scan menus */);
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
	CFrameWndEx::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	if(0==m_wndToolBar.GetSafeHwnd()) return;
	if(0==m_wndStatusBar.GetSafeHwnd()) return;
	if(0==m_wndDirsCtrl.GetSafeHwnd()) return;
	if(0==m_wndFilesCtrl.GetSafeHwnd()) return;

	RepositionBars(AFX_IDW_CONTROLBAR_FIRST + 40, AFX_IDW_CONTROLBAR_FIRST + 50, 0, reposExtra, &m_rectBorder, NULL, TRUE);

	RECT ToolBarRect={0};
	m_wndToolBar.GetWindowRect(&ToolBarRect);

	::MapWindowPoints(NULL, GetSafeHwnd(), (LPPOINT)&ToolBarRect, 2);

	RECT StatusBarRect={0};
	m_wndStatusBar.GetWindowRect(&StatusBarRect);
	::MapWindowPoints(NULL, GetSafeHwnd(), (LPPOINT)&StatusBarRect, 2);

	int files_height = 200;
	int height = StatusBarRect.top-ToolBarRect.bottom-files_height;
	if(height<0)
	{
		files_height = StatusBarRect.top-ToolBarRect.bottom;
		height = 0;
	}

	int width = StatusBarRect.right-StatusBarRect.left-200;
	if(width<0) width = 0;

	m_wndDirsCtrl.SetWindowPos(NULL,0,ToolBarRect.bottom, 200, StatusBarRect.top-ToolBarRect.bottom,SWP_NOZORDER);
	m_wndFilesCtrl.SetWindowPos(NULL,200, ToolBarRect.bottom, width, files_height, SWP_NOZORDER);

	CView* pView = GetActiveView();
	if(pView)
		pView->SetWindowPos(NULL, 200,ToolBarRect.bottom+200, width,height,SWP_NOZORDER);
}

void CMainFrame::OnSizing(UINT /*fwSide*/, LPRECT /*pRect*/)
{
	//CFrameWndEx::OnSizing(fwSide, pRect);

	// TODO: Add your message handler code here
}

void CMainFrame::OnWindowPosChanged(WINDOWPOS* lpwndpos)
{
	CFrameWndEx::OnWindowPosChanged(lpwndpos);

	// TODO: Add your message handler code here
}

void CMainFrame::OnWindowPosChanging(WINDOWPOS* /*lpwndpos*/)
{
	//CFrameWndEx::OnWindowPosChanging(lpwndpos);

	// TODO: Add your message handler code here
}

void CMainFrame::OnEnterSizeMove()
{
	// TODO: Add your message handler code here and/or call default

	//CFrameWndEx::OnEnterSizeMove();
}

void CMainFrame::OnExitSizeMove()
{
	// TODO: Add your message handler code here and/or call default

	//CFrameWndEx::OnExitSizeMove();
}

int CMainFrame::CheckForChildren(LPCTSTR szPath)
{
	CFileFind finder;
	CString strFile;
	strFile.Format(_T("%s\\*"),szPath);

	BOOL bWorking = finder.FindFile(strFile);
	while (bWorking)
	{
		bWorking = finder.FindNextFile();
		if(finder.IsDirectory())
		{
			CString strName = finder.GetFileName();
			if(strName==_T(".") || strName==_T("..")) continue;

			return 1;
		}
	}

	return 0;
}

void CMainFrame::FillDisks()
{
	HIMAGELIST hList=NULL;
	TCHAR szTemp[256] = {0};
	if (GetLogicalDriveStrings(_ARRAYSIZE(szTemp), szTemp))
	{
		TCHAR* seek = szTemp;
		while(*seek)
		{
			SHFILEINFO sfi_small={0};
			hList = (HIMAGELIST)SHGetFileInfo(seek,0,&sfi_small,sizeof(SHFILEINFO),SHGFI_SMALLICON|SHGFI_SYSICONINDEX);
			*(seek+2) = 0;

			TVINSERTSTRUCT tv={0};
			tv.hInsertAfter = TVI_LAST;
			tv.hParent = TVI_ROOT;

			tv.item.mask = TVIF_CHILDREN|TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_TEXT|TVIF_PARAM;
			tv.item.pszText = seek;
			tv.item.iImage = sfi_small.iIcon;
			tv.item.iSelectedImage = sfi_small.iIcon;
			tv.item.cChildren = CheckForChildren(seek);
			tv.item.lParam = 0;

			/*HTREEITEM hItem = */m_wndDirsCtrl.InsertItem(&tv);

			seek+=_tcslen(seek)+2;
		}
	}

	if(hList)
	{
		TreeView_SetImageList(m_wndDirsCtrl.GetSafeHwnd(), hList, TVSIL_NORMAL);
		ListView_SetImageList(m_wndFilesCtrl.GetSafeHwnd(),hList, LVSIL_SMALL);
	}
}

void CMainFrame::FillDirTree(HTREEITEM hRoot, CString const& strPath)
{
	CFileFind finder;
	CString strFile;
	strFile.Format(_T("%s\\*"),strPath);

	HIMAGELIST hList=NULL;
	BOOL bWorking = finder.FindFile(strFile);
	while (bWorking)
	{
		bWorking = finder.FindNextFile();
		if(finder.IsDirectory())
		{
			CString strName = finder.GetFileName();
			if(strName==_T(".") || strName==_T("..")) continue;

			CString strPath = finder.GetFilePath();
			SHFILEINFO sfi_small={0};
			hList = (HIMAGELIST)SHGetFileInfo(strPath,0,&sfi_small,sizeof(SHFILEINFO),SHGFI_SMALLICON|SHGFI_SYSICONINDEX);

			TVINSERTSTRUCT tv={0};
			tv.hInsertAfter = TVI_LAST;
			tv.hParent = hRoot;

			tv.item.mask = TVIF_CHILDREN|TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_TEXT|TVIF_PARAM;
			tv.item.pszText = (LPTSTR)(LPCTSTR)strName;
			tv.item.iImage = sfi_small.iIcon;
			tv.item.iSelectedImage = sfi_small.iIcon;
			tv.item.cChildren = CheckForChildren(strPath);
			tv.item.lParam = 0;

			/*HTREEITEM hItem = */m_wndDirsCtrl.InsertItem(&tv);
		}
	}

	if(hList)
	{
		TreeView_SetImageList(m_wndDirsCtrl.GetSafeHwnd(), hList, TVSIL_NORMAL);
		ListView_SetImageList(m_wndFilesCtrl.GetSafeHwnd(),hList, LVSIL_SMALL);
	}
}

void CMainFrame::OnTreeItemExpanding(NMHDR* pNotifyStruct, LRESULT* result)
{
	LPNMTREEVIEW pnmtv = (LPNMTREEVIEW) pNotifyStruct;
	*result=0;

	if(pnmtv->action!=TVE_EXPAND) return;

	DWORD_PTR data = m_wndDirsCtrl.GetItemData(pnmtv->itemNew.hItem);
	if(data) return;

	FillDirTree(pnmtv->itemNew.hItem, GetTreeItemPath(pnmtv->itemNew.hItem, NULL));

	m_wndDirsCtrl.SetItemData(pnmtv->itemNew.hItem, 1);
}

void CMainFrame::OnTreeItemChanged(NMHDR* pNotifyStruct, LRESULT* result)
{
	*result=0;

	if(NULL == m_wndFilesCtrl.GetSafeHwnd()) return;

	m_wndFilesCtrl.DeleteAllItems();

	LPNMTREEVIEW pnmtv = (LPNMTREEVIEW) pNotifyStruct;

	HIMAGELIST hList=NULL;
	CFileFind finder;
	BOOL bWorking = finder.FindFile(GetTreeItemPath(pnmtv->itemNew.hItem, _T("*")));
	while(bWorking)
	{
		bWorking = finder.FindNextFile();

		CString strName = finder.GetFileName();
		if(strName==_T(".") || strName==_T("..")) continue;

		SHFILEINFO sfi_small={0};
		hList = (HIMAGELIST)SHGetFileInfo(finder.GetFilePath(),0,&sfi_small,sizeof(SHFILEINFO),SHGFI_SMALLICON|SHGFI_SYSICONINDEX);

		LVITEM lv = {0};
		lv.mask = LVIF_IMAGE|LVIF_TEXT;
		lv.iItem = -1;
		lv.iImage = sfi_small.iIcon;
		lv.pszText = (LPTSTR)(LPCTSTR)strName;

		m_wndFilesCtrl.InsertItem(&lv);
	}

	if(hList)
	{
		TreeView_SetImageList(m_wndDirsCtrl.GetSafeHwnd(), hList, TVSIL_NORMAL);
		ListView_SetImageList(m_wndFilesCtrl.GetSafeHwnd(),hList, LVSIL_SMALL);
	}
}

LPCTSTR CMainFrame::GetTreeItemPath(HTREEITEM hItem, LPCTSTR szEnd)
{
	static TCHAR szPath[10*MAX_PATH]={0};

	TCHAR* seek = szPath+_ARRAYSIZE(szPath)-1;

	if(szEnd)
	{
		size_t end_len = _tcslen(szEnd)+1;
		seek-=end_len;
		if(--seek<szPath) return szPath+_ARRAYSIZE(szPath)-1;
		wcscpy_s(seek, end_len+1, szEnd);
		if(--seek<szPath) return szPath+_ARRAYSIZE(szPath)-1;
		*seek=_T('\\');
	}

	while(hItem)
	{
		CString strText=m_wndDirsCtrl.GetItemText(hItem);
		seek-=strText.GetLength();
		if(seek<szPath) return szPath+_ARRAYSIZE(szPath)-1;

		_tcscpy_s(seek, strText.GetLength()+1, strText);
		*(seek+strText.GetLength())=_T('\\');

		if(--seek<szPath) return szPath+_ARRAYSIZE(szPath)-1;
		*seek=_T('\\');

		hItem = m_wndDirsCtrl.GetParentItem(hItem);
	}

	return ++seek;
}

void CMainFrame::OnListItemChanged(NMHDR* pNotifyStruct, LRESULT* /*result*/)
{
	LPNMLISTVIEW pnmv = (LPNMLISTVIEW) pNotifyStruct;
	CString strText = m_wndFilesCtrl.GetItemText(pnmv->iItem, 0);

	LPCTSTR szPath = GetTreeItemPath(m_wndDirsCtrl.GetSelectedItem(), strText);
	AfxGetApp()->OpenDocumentFile(szPath);
}