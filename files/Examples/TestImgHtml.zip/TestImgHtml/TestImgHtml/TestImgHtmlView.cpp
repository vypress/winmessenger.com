
// TestImgHtmlView.cpp : implementation of the CTestImgHtmlView class
//

#include "stdafx.h"
#include "TestImgHtml.h"

#include "TestImgHtmlDoc.h"
#include "TestImgHtmlView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CTestImgHtmlView

IMPLEMENT_DYNCREATE(CTestImgHtmlView, CHtmlView)

BEGIN_MESSAGE_MAP(CTestImgHtmlView, CHtmlView)
END_MESSAGE_MAP()

// CTestImgHtmlView construction/destruction

CTestImgHtmlView::CTestImgHtmlView()
{
	// TODO: add construction code here

}

CTestImgHtmlView::~CTestImgHtmlView()
{
}

BOOL CTestImgHtmlView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CHtmlView::PreCreateWindow(cs);
}

void CTestImgHtmlView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	// TODO: Add your specialized code here and/or call the base class
	CTestImgHtmlDoc* pDoc = (CTestImgHtmlDoc*) GetDocument();

	//  change the code to go where you'd like.
	if(pDoc->m_strPath.GetLength()>0)
		Navigate2(pDoc->m_strPath,NULL,NULL);
	else Navigate2(_T("about:blank"),NULL,NULL);
}

void CTestImgHtmlView::OnRButtonUp(UINT /*nFlags*/, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CTestImgHtmlView::OnContextMenu(CWnd* /*pWnd*/, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CTestImgHtmlView diagnostics

#ifdef _DEBUG
void CTestImgHtmlView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CTestImgHtmlView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}

CTestImgHtmlDoc* CTestImgHtmlView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestImgHtmlDoc)));
	return (CTestImgHtmlDoc*)m_pDocument;
}
#endif //_DEBUG


// CTestImgHtmlView message handlers
