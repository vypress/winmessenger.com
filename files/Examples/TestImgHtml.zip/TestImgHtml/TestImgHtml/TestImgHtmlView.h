
// TestImgHtmlView.h : interface of the CTestImgHtmlView class
//


#pragma once


class CTestImgHtmlView : public CHtmlView
{
protected: // create from serialization only
	CTestImgHtmlView();
	DECLARE_DYNCREATE(CTestImgHtmlView)

// Attributes
public:
	CTestImgHtmlDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // called first time after construct

// Implementation
public:
	virtual ~CTestImgHtmlView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TestImgHtmlView.cpp
inline CTestImgHtmlDoc* CTestImgHtmlView::GetDocument() const
   { return reinterpret_cast<CTestImgHtmlDoc*>(m_pDocument); }
#endif

