﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

using WinMessengerService;

namespace WindowsFormsClient
{
    public partial class Form1 : Form
    {
        CoWinMessengerClass _CoWmService;
        CoWinMessengerUsersListProviderClass _CoUsersListProvider;
        UsersListEventsListener _UsersListListener;
        MessagesListener _MsgListener;

        SolidBrush _foreColorBrush;

        const String _strFrom = "NET_CLIENT";

        public Form1()
        {
            InitializeComponent();
            _CoWmService = new CoWinMessengerClass();

            _MsgListener = new MessagesListener();
            String[] arrayFrom = { _strFrom, System.Environment.UserName, System.Environment.MachineName, @"*"};
            _CoWmService.AddNames(arrayFrom, _MsgListener);

            _CoUsersListProvider = new CoWinMessengerUsersListProviderClass();

            //Use the standard connection point interface
            WinMessengerService._IUsersListEventsListener_OnUsersListUpdateEventHandler handler = new _IUsersListEventsListener_OnUsersListUpdateEventHandler(this.CoWmService_OnUsersListUpdate);
            _CoUsersListProvider._IUsersListEventsListener_Event_OnUsersListUpdate += handler;

            //Use optional AddUsersListEventsListener method
            //_UsersListListener = new UsersListEventsListener(this);
            //_CoUsersListProvider.AddUsersListEventsListener(_UsersListListener);

            LoadUsersList();
        }

        public void LoadUsersList()
        {
            comboBoxTo.Items.Clear();
            Object[,] obj_ul = _CoUsersListProvider.GetUsersList() as Object[,];
            if (obj_ul == null) return;

            int items0 = obj_ul.GetLength(0);
            //int items1 = obj_ul.GetLength(1);

            int loBound0 = obj_ul.GetLowerBound(0);
            int upBound0 = obj_ul.GetUpperBound(0);

            //int loBound1 = obj_ul.GetLowerBound(0);
            //int upBound1 = obj_ul.GetUpperBound(0);

            for (int i = loBound0; i <= upBound0; i++)
            {
                //MessageBox.Show(obj_ul.GetType().ToString());
                //if (typeof(String) == obj_ul[i, 0].GetType())
                //{
                //}

                comboBoxTo.Items.Add(new CbUserItem(obj_ul[i, 0] as String, obj_ul[i, 1] as String, (int)obj_ul[i, 2], 0));

                Object[,] obj_next_ul = obj_ul[i, 3] as Object[,];

                if (obj_next_ul == null) continue;

                int loBound00 = obj_next_ul.GetLowerBound(0);
                int upBound00 = obj_next_ul.GetUpperBound(0);
                for (int j = loBound00; j <= upBound00; j++)
                {
                    comboBoxTo.Items.Add(new CbUserItem(obj_next_ul[j, 0] as String, obj_next_ul[j, 1] as String, (int)obj_next_ul[j, 2], 1));
                }
            }
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            SendEventsListener se_listener = new SendEventsListener();
            String[] arrayTo = {comboBoxTo.Text};

            MSG_TYPE msgType = radioUser.Checked ? MSG_TYPE.SMB : MSG_TYPE.MAILSLOT;
            se_listener.Cookie = _CoWmService.SendTextMessage(msgType, arrayTo, _strFrom, textBoxMessage.Text, se_listener);
        }

        // Define event handlers.
        // UsersList changed
        private void CoWmService_OnUsersListUpdate(uint lFlag)
        {
            LoadUsersList();
            //MessageBox.Show("UserList has been changed!", "WinMessengerUsersListProvider connection point");
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (_UsersListListener != null)
                _CoUsersListProvider.RemoveUsersListEventsListener(_UsersListListener);

            _CoWmService.RemoveListener(_MsgListener);
        }

        private void comboBoxTo_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            ComboBox cBox = (ComboBox)sender;
            CbUserItem cbItem = cBox.Items[e.Index] as CbUserItem;

            //Brush brush;

            // Create the brush using the ForeColor specified by the DrawItemEventArgs
            if (_foreColorBrush == null)
                _foreColorBrush = new SolidBrush(e.ForeColor);
            else if (_foreColorBrush.Color != e.ForeColor)
            {
                // The control's ForeColor has changed, so dispose of the cached brush and
                // create a new one.
                _foreColorBrush.Dispose();
                _foreColorBrush = new SolidBrush(e.ForeColor);
            }

            // Select the appropriate brush depending on if the item is selected.
            // Since State can be a combinateion (bit-flag) of enum values, you can't use
            // "==" to compare them.
            //if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
            //    brush = SystemBrushes.HighlightText;
            //else
            //    brush = foreColorBrush;

            // Perform the painting.
            e.DrawBackground();

            SizeF stringSize = e.Graphics.MeasureString(e.Font.Name, e.Font);

            // Set the height and width of the item
            //e.ItemHeight = (int)stringSize.Height;
            //e.ItemWidth = (int)stringSize.Width;
            int Y = e.Bounds.Y + (e.Bounds.Height - (int)stringSize.Height) / 2;
            int X = e.Bounds.X + cbItem._nLevel * 10;

            e.Graphics.DrawString(cbItem._strName, e.Font, _foreColorBrush, new RectangleF(X + imageListUsers.ImageSize.Width, Y, e.Bounds.Width - X, e.Bounds.Height));

            if ((e.State & DrawItemState.Focus) == DrawItemState.Focus)
                e.DrawFocusRectangle();

            int nImageIndex = (cbItem._nType == 0x00000002) ? 0 : 1;//RESOURCEDISPLAYTYPE_SERVER         0x00000002
            imageListUsers.Draw(e.Graphics, new Point(X, e.Bounds.Y), nImageIndex);
        }

        private void comboBoxTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cBox = (ComboBox)sender;
            CbUserItem cbItem = cBox.Items[cBox.SelectedIndex] as CbUserItem;
            bool bUserSeleted =  (cbItem._nType == 0x00000002);
            radioGroup.Checked = !bUserSeleted;
            radioUser.Checked = bUserSeleted;
        }
    }

    class CbUserItem
    {
        public CbUserItem(String strName, String strDescription, int nType, int nLevel)
        {
            _strName = strName;
            _strDescription = strDescription;
            _nType = nType;
            _nLevel = nLevel;
        }

        public override string ToString()
        {
            return _strName;
        }

        public String _strName;
        public String _strDescription;
        public int _nType;
        public int _nLevel;
    }

    public class MessagesListener : _IMessagesListener
    {
        #region _IMessagesListener Members

        public void OnReceiveMessage(MSG_TYPE nType, String strFrom, String strTo, String strMsg)
        {
            MessageBox.Show(String.Format("Message from {0} to {1}.\r\n{2}", strFrom, strTo, strMsg), "New Message received!");
        }

	    public void OnServiceError(int nErrType, int lErr, int lErrData, String strName, String strError)
        {
            MessageBox.Show(String.Format("Error information:\r\ndata1: {0:X8}\r\ndata2: {1:X8}\r\ndata3: {2:X8}\r\nname: {3}\r\ndescription: {4}", nErrType, lErr, lErrData, strName, strError), "Service error occured!");
        }

        #endregion
    }

    public class SendEventsListener : _ISendEventsListener
    {
        int _cookie;

        public SendEventsListener()
        {
            _cookie = -1;
        }

        public int Cookie
        {
            set
            {
                _cookie = value;
            }
            
            get
            {
                return _cookie;
            }

        }

        #region _ISendEventsListener Members

        public void OnSendStatusChanged(int lCookie, object varStatuses, bool bFinal)
        {
            if (!bFinal) return;

            if (_cookie == lCookie)
            {
                Object[,] obj_statuses = varStatuses as Object[,];
                if (obj_statuses == null)
                {
                    MessageBox.Show(String.Format("Unable to send the message with ID {0}.", _cookie), "WinMessenger");
                    return;
                }

                int loBound0 = obj_statuses.GetLowerBound(0);
                int upBound0 = obj_statuses.GetUpperBound(0);

                for (int i = loBound0; i <= upBound0; i++)
                {
                    UInt32 nStatus = (UInt32)obj_statuses[i, 1];
                    if (nStatus == 0)
                        MessageBox.Show(String.Format("The message to {0} was sent successfully.", obj_statuses[i, 0]), "WinMessenger");
                    else
                        MessageBox.Show(String.Format("Unable to send the message to {0}.", obj_statuses[i,0]), "WinMessenger");
                }
            }
            //throw new NotImplementedException();
        }

        #endregion
    }

    public class UsersListEventsListener : _IUsersListEventsListener
    {
        Form1 ParentForm;

        public UsersListEventsListener(Form1 form)
        {
            ParentForm = form;
        }

        #region _IUsersListEventsListener Members

        public void OnUsersListUpdate(uint lFlag)
        {
            ParentForm.LoadUsersList();
            //MessageBox.Show("UserList has been changed!", "WinMessengerUsersListProvider");
            //throw new NotImplementedException();
        }

        #endregion
    }
}